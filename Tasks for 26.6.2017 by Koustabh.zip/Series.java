class Series
{
public static void main(String []ar)
{
int i, j, k;
    for(i=1;i<=4;i++)
    {
      
        for(k=1;k<(i*2);k++)
        {
	if(i==2)
	{
	System.out.print("*");
	}
	else{
	System.out.print("x");
}
        }

System.out.println();
    }
    for(i=3;i>=1;i--)
    {
       
        for(k=1;k<(i*2);k++)
        {
	if(i==2)
	{
              	System.out.print("*");
	}
	else{
	System.out.print("x");
	}
        }
       System.out.println();
    }
  }
}