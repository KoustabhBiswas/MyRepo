class pattern1
{
  public static void main(String[ ] ar)
  {
    int i,j;
    for(i=1;i<=5;i++)
    {
      for(j=1;j<=i;j++)
      {
         System.out.print("\t"+j);
       }
       System.out.println();
    }
  }
}