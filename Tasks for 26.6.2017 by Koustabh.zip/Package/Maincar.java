package Pack3;
import java.util.*;
import Pack1.Car;
import Pack2.*;
public class Maincar {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		 Car obj1 = new childcar();
	
		obj1.basecar();
		
	}

}
