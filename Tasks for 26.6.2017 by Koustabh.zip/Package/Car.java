package Pack1;

public abstract class Car {
	protected int  engine_cc;
	public abstract void basecar();
		
	 
}
