import java.util.*;
public class Factorial {

   public static void main(String[] args) {
       int n;
       Scanner sc=new Scanner(System.in);
       System.out.println("The number is:  ");
       n=sc.nextInt();
       int result = factorial(n);
       System.out.println("The factorial is " + result);
   }

   public static int factorial(int n) {
       if (n == 0) {
           return 1;
       } else {
           return n * factorial(n - 1);
       }
   }
}